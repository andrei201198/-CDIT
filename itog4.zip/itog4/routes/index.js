var express = require('express');
var router = express.Router();
var path = require('path');


router.get('/',function(req,res,next){	
	res.render('Starter', {title:"Super App"});	
});


router.get('/vivod', function(req, res) {
	var MongoClient = require('mongodb').MongoClient;
	var dbHost = 'mongodb://127.0.0.1:27017/primer15';
	var myCollection = 'phone';
	MongoClient.connect(dbHost, function(err, db){
	   console.log('Соединились с БД...');
		  db.collection(myCollection).find({}).toArray(
		    function(err, vivod){
	      	      res.send(vivod);
	        });
});
});


router.post('/save', function(req, res) {
var users={
	"name":req.body.name,
	"price":req.body.price,
	"company":req.body.company,
	"year":req.body.year
};
	var MongoClient = require('mongodb').MongoClient;
	var dbHost = 'mongodb://127.0.0.1:27017/primer15';
	var myCollection = 'phone';
	MongoClient.connect(dbHost, function(err, db){
	   console.log('Соединились с БД...');
	   	  db.collection(myCollection).insert(users);
	   		 console.log('Добавили в БД...'); 
	        });
	res.redirect(303, '/' );
		}); 
	        

router.post('/udalenie', function(req, res) {
var users = {
	'name': req.body.name
}
	var MongoClient = require('mongodb').MongoClient;
	var dbHost = 'mongodb://127.0.0.1:27017/primer15';
	var myCollection = 'phone';
	MongoClient.connect(dbHost, function(err, db){
	   console.log('Соединились с БД...');
	   	  db.collection(myCollection).remove({"name": users.name}, function(err, recs){
	  if(err) throw err;
	  console.log("Successfully удалили ..."+ users.name);
	  })
	  });
	res.redirect(303, '/admin' );
		}); 


router.post('/redaktor', function(req, res) {
var use = {'name1': req.body.name1
};
	var MongoClient = require('mongodb').MongoClient;
	var dbHost = 'mongodb://127.0.0.1:27017/primer15';
	var myCollection = 'phone';
	MongoClient.connect(dbHost, function(err, db){
	   console.log('Соединились с БД...');
	   console.log(use.name1);
	   	   	  db.collection(myCollection).update({"name": use.name1}, {
	   	   	  	"name": req.body.name,
	   	   	  	"price": req.body.price,
	   	   	  	"company": req.body.company,
	   	   	  	"year": req.body.year
	   	   	

	   	   	  });
	   	   	  
		  });
	res.redirect(303, '/admin' );
});
	




module.exports = router;
