//Angular Starter App
var main = angular.module("main", ['ui.router'])
.config(function($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/');
        $stateProvider
            .state('home', {
                url: '/',
                templateUrl: 'Index.html'
                
            })
            .state('contact', {
                url: '/contact',
                templateUrl: 'Contact.html'
            })
            .state('about', {
                url: '/about',
                templateUrl: 'About.html'
            })
            .state('vivod',{
                url: '/vivod',
                templateUrl: 'vivod.html',
                controller: 'myController'
            })
            .state('save',{
                url: '/vstavka',
                templateUrl: 'vstavka.html'
            })
            .state('udalenie',{
                url: '/udalenie',
                templateUrl: 'udalenie.html'
            })
            .state('redaktor',{
                url: '/redaktor',
                templateUrl: 'redaktor.html'
            })
            .state('login',{
                url: '/login',
                templateUrl: 'login.html',
                caseInsensitiveMatch: true,
                controller: 'AuthController'
            })
            .state('register',{
                url: '/register',
                templateUrl: 'register.html',
                caseInsensitiveMatch: true,
                controller: 'AuthController'
            })
			.state('unauth',{
                url: '/unauth',
                templateUrl: 'unauth.html',
                caseInsensitiveMatch: true
            });                                 
    });


main.controller('myController', function($scope, $http) {
   $scope.vivod = [];
    var request = $http.get('/vivod');    
    request.success(function(vivod) {
        $scope.vivod = vivod;
    });
    request.error(function(vivod){
        console.log('Error: ' + vivod);
    });
});


main.run(function($http,$rootScope){
    if(sessionStorage.length > 0){
        $rootScope.current_user = sessionStorage.current_user;
        $rootScope.authenticated = true;
    }else{
        $rootScope.authenticated = false;
        $rootScope.current_user = 'Guest';
    }
    
    $rootScope.signout = function(){
        $http.get('auth/signout');
        $rootScope.authenticated = false;
        $rootScope.current_user = 'Guest';
        sessionStorage.clear();
    };
});       


module.exports = main;
